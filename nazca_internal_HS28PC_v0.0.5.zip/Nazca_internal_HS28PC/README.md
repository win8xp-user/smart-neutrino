# WELCOME TO THE HS28PC nazca pdk internal release

This that you have in your hand is version 0.0.1 of the HS28PC nazca PDK internal.
This PDK is intedend for interal use of smart photonics. 


## HOW DO I install?

With this README file you received a .whl file, that file can be easily installed using pip install. 

If you don't know how to install using pip try a quick google search ;) 

## HOW do I use it ? 

Once the PDK is installed you can use it like any other nazca PDK, the naming convention is exactly the same
as the PDK released by Bright, so you should be familiar with it. In case you are not there will be documentation attached to the release in the near future. 
In the MPW_cell.py file you can find an example on how to create an MPW cell. 

# DO NOT DISTRIBUTE OUTSIDE SMART PHOTONICS ! 
not a joke please don't do it :*


# CHANGELOG 

#### v0.0.5
added bb metal to layers for better visual guidance

#### v0.0.4 
fix accuracy layer 57 

#### v0.0.3
updated with new blueprint 
removed deep under metal_dc and metal RF 


#### v0.0.2
fixed cell_id
improved documentation 
#### v0.0.1
- this is the first release 