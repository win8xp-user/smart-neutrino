
# This file is part of an internal release of SMART photonics PDK for Nazca Design
# ---------------------------------------------------------------
#
# Copyright (c) SMART photonics
#
# ----------------------------------------------------------------
# This PDK file is FOR SMART photonics internal use ONLY
#
# This file is part of a Nazca Design PDK for use with Nazca Design only.
# This file can only be used INTERNALLY to SMART PHOTONICS.
#
# If you have received this file in error, by mistake, or from a
# non-authorized source then delete this file and all copies immediately
# and notify the sender.
#
# This file is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# For questions and/or comments:
# Email: damiano.massella@smartphotonics.nl
#-----------------------------------------------------------------------

"""
SMART Photonics Project example.
Smart Photonics uPDK HS28PC 
pdk_version=v3.0.0

"""

# load the main Nacza-Design module and initialize logging.
import nazca as nd
nd.logfile(name=__file__, stdout=False)

# load PDK for the Smart Photonics MPW process and switch on logging
import sp_HS28PC as sp

# load packaging templates
from nazca.demopackager.packages import Package1

# switch on pin2pin DRC
nd.pin2pin_drc_on()


#==============================================================================
# Customize an MPW cell template which serves as the MPW project template.
# The cell can combine foundry, packaging, testing and other templates.
#==============================================================================
with nd.Cell('CELL') as CELL:
    #A1. Create this CELL to serve as the MPW reference cell.
    #    It will be filled below with the foundry MPW info (the die)
    #    and packaging info.

    #B1. Create a DIE (chip) object and customize its settings:
    DIE = sp.DesignArea(name='Area-1')
    DIE.coating('AR', 'HR')

    #B2. The DIE object can generate a cell: DIE.cell.
    #    Put it in this MPW cell. It returns a 'die' instance:
    die = DIE.cell().put(0)

    #B3. Make all DIE pins available in this CELL by 'raising' the pins:
    die.raise_pins()

    #C1. Create a PACKAGE object and customize its settings:
    PACKAGE = Package1(name='Package-A1', die_length=DIE.length, die_height=DIE.height)
    PACKAGE.RFcount = 0
    PACKAGE.DCedge = 100

    #C2. Put the PACKAGE cell in this MPW cell.
    package = PACKAGE.cell().put(0)

    #C3. Make all 'package' pins available in this CELL by 'raising' the pins:
    package.raise_pins()


# =============================================================================
# Define your building blocks
# =============================================================================
# with nd.Cell('myblock1') as B1:
# ...


#==============================================================================
# Create the topcell of your design:
#==============================================================================
with nd.Cell('Design1') as Design1:
    # =========================================================================
    # put MPW template and the io building-blocks you need
    # NOTE: in Smart the optical-io positions provided are mandatory.
    #       the electrical-io are free to choose.
    # =========================================================================
    # Place a MPW template which includes the pins to place io-blocks:
    MPWcell = CELL.put(0)
    sp.nazca_logo().put(500, 3500, scale=1.5)
    # Place a pad on all DC electrical IOs
    #   and store them in a dictionary:
    DC = {name:sp.sp_pad_dc_box().put('rc', pin)
        for name, pin in MPWcell.pin.items() if 'dc' in name}

    # Place a pad on all RF electrical IOs
    #   and store them in a dictionary:
    RF = {name:sp.sp_pad_gsg().put(pin)
        for name, pin in MPWcell.pin.items() if 'rf' in name}

    # Place optical IO-blocks on some IO template positions
    #   and store them in a dictionary:
    ioWest = ['ioW050', 'ioW090', 'ioW130' , 'ioW170', 'ioW210', 'ioW250']
    ioEast = ['ioE050', 'ioE090', 'ioE130']
    IO = {name:sp.io(MPWcell.pin[name], bendgrid=True).put() for name in ioWest+ioEast}

    # print to stdout which io-blocks have been created:
    print("Available io-blocks:")
    print("DC:", list(DC.keys()))
    print("RF:", list(RF.keys()))
    print("IO:", list(IO.keys()))


    # =========================================================================
    # connect design structures to the io-building blocks.
    # =========================================================================
    sp.shallow.strt(250).put(IO['ioW090'])

    sp.sp_s2d().put(IO['ioE130'])
    sp.deep.strt(length=500).put()
    sp.sp_eopm_dc_dp().put(flip=True)
    sp.deep.bend(angle=45).put()
    sp.sp_d2s().put()
    sp.shallow.strt(length=200).put()
    sp.shallow.rot2ref(angle=0).put()
    sp.sp_soa_ncontact(length=50).put()

    sp.metaldc.strt(length=1000).put(DC['dcT017'].pin['c0'])

    # DRC error examples
    sp.deep.strt(length=100).put() # xs error
    sp.deep.strt(length=200, width=10).put() # width error
    sp.deep.bend(angle=45).put(nd.cfg.cp.rot(0.5)) # angle and width error
    soa = sp.sp_soa_ncontact().put() # instantiation angle error (via angle_drc)
    sp.metaln.strt(length=250).put(soa.pin['c1'])
    sp.metaldc.strt(length=250).put(soa.pin['c0'])


    # RF interconnects
    sp.metalrf.strt(length=500).put(1000, 2500)
    e1 = sp.metalrf.bend(angle=45).put()
    e2 = sp.metalrf.strt(length=100).put(1700, 2200, 90)
    sp.metalrf.bend_strt_bend_p2p(pin1=e1.pin['b0'], pin2=e2.pin['b0']).put()

    sp.deep.strt(50).put(500, 500)
    sp.deep.bend(angle=90).put()
    sp.deep.strt(50).put()

    sp.sp_gsg_arc().put(1000,1000)
    sp.sp_cell_id().put(0,0)


#==============================================================================
# Export the mask layout
#==============================================================================
nd.export_gds(topcells=Design1, filename='MPW_template.gds', angleDRC=True)

